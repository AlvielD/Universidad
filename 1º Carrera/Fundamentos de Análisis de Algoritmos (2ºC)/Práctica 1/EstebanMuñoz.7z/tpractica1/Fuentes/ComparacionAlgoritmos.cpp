
#include <iostream>
#include "Test.h"
//#include "ConjuntoInt.h"
using namespace std;

/* Programa principal */
int main()
{
	cout << "Comprobando el el metodo secuencial";
	TestAlgoritmo t1;
	t1.comprobarAlgoritmo();

	return 0;
}

